import sys

def mmm(args):
  smallPos = 100000000
  largeNeg = -100000000
  for arg in args:
    n = int(arg)
TBD
  return (smallPos, largeNeg)

TBD call to mmm(sys.argv[1:])
print("Smallest positive=%d Largest negative=%d" % (smallPos, largeNeg))
